# mypackage
This library was created as a practice example on how to create my own packages in python

# intent
To find the top n numbers of a list or array